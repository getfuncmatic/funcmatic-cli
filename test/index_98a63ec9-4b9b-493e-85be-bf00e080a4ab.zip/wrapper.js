'use strict';

const axios = require('axios')
const pino = require('pino')
//const lambda = require('funcmatic-lambdaproxyintegration')
const createResult = require('@funcmatic/lambda-response')
const createError = require('http-errors')

var userhandler = require('./index')

// we need to pull the following from the AWS context object and put into Funcmatic context
// 
module.exports.handler = async (event, awscontext) => {  
  var res = createResult()
  awscontext.callbackWaitsForEmptyEventLoop = false
  event.context.functionRequestId = awscontext.invokeid
  event.context.functionVersion = awscontext.functionVersion
  event.context.getTimeRemainingInMillis = awscontext.getTimeRemainingInMillis

  var log = createLogger(pino, event.context)
  var request = createRequest(axios, event.context)
  var error = createError
  
  log.info({ msgType: "REQUEST" }, "")
  try {
    var data = await userhandler.handler({ 
      event: event.event, 
      context: event.context,
      func: { log, request, error },
    })
    var res = createResult(data)
    if (res.statusCode >= 400) {
      log.error({ msgType: "RESPONSE" }, res)
    } else {
      log.info({ msgType: "RESPONSE" }, res)
    }
    return res
  } catch (err) {
    var res = createResult(err)
    log.error({ msgType: "RESPONSE" }, res)
    return res.error(err)
  }
}

function createRequest(axios, context) {
  var frequest = axios.create({
    baseURL: context.baseURL || 'https://funcmatic.io/dev/',
    timeout: 1000 * 29,  // all funcmatic requests have a 30 second timeout because of API gateway
    headers: {
      'X-Correlation-Id': context.correlationId,
      'X-Log-Level': context.logLevel,
      'Authorization': (process.env.FUNCKEY && `Funckey ${process.env.FUNCKEY}`) || `Funckey TEST-API-KEY`
    }
  })
  return frequest
}

function createLogger(pino, context) {
  var log = pino({
    level: context.logLevel,
    base: createLoggerBase(context),
  })
  return log
}

function createLoggerBase(context) {
  return {
    correlationId: context.correlationId,
    correlationIdNew: context.correlationIdNew,
    username: context.username,
    functionRequestId: context.functionRequestId,
    functionId: context.functionId,
    functionName: context.functionName,
    functionUsername: context.functionUsername,
    functionQualifier: context.functionQualifer,
    functionVersion: context.functionVersion,
    functionAlias: context.functionAlias,
    msgType: "USER"
  }
}