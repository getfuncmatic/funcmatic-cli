'use strict';

module.exports.handler = async ({ event, context, func }) => {
  console.log("EVENT", JSON.stringify(event, null, 2));
  console.log("CONTEXT", JSON.stringify(context, null, 2));
  func.log.info("called!");
  if (event.params.unhandled) {
    func.log.info("unhandled", event.params.unhandled);
    throw func.error(event.params.statusCode, event.params.errorMessage);
  }
  if (event.params.handled) {
    func.log.info("handled", event.params.handled);
    return func.error(event.params.statusCode, event.params.errorMessage);
  }
  func.log.info("another level");
  try {
    func.log.info("about to request");
    var res = (await func.request.get('danieljyoo/funcmatic-helloworld')).data;
    func.log.info("returned", res);
    return {
      message: `Welcome to FUNCMATIC! (${context.functionRequestId})`,
      event,
      context,
      res
    };
  } catch (err) {
    console.log("error", JSON.stringify(err, null, 2));
    func.log.info(JSON.stringify(err, null, 2));
    return err;
  }
};
